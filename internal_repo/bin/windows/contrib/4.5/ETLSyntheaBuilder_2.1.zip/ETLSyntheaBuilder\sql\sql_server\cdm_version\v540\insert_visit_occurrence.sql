
insert into @cdm_schema.visit_occurrence (
visit_occurrence_id,
person_id,
visit_concept_id,
visit_start_date,
visit_start_datetime,
visit_end_date,
visit_end_datetime,
visit_type_concept_id,
provider_id,
care_site_id,
visit_source_value,
visit_source_concept_id,
admitted_from_concept_id,
admitted_from_source_value,
discharged_to_concept_id,
discharged_to_source_value,
preceding_visit_occurrence_id
)
select
  	av.visit_occurrence_id,
	p.person_id,                          

	case lower(av.encounterclass) 
		when 'ambulatory'  then 9202
		when 'emergency'   then 9203
		when 'inpatient'   then 9201
		when 'wellness'    then 9202
		when 'urgentcare'  then 9203 
		when 'outpatient'  then 9202
	else 0
	end,
	av.visit_start_date,
	av.visit_start_date,
	av.visit_end_date,
	av.visit_end_date,
	32827,                             
	pr.provider_id,                                 
	null,                                 
	av.encounter_id,
	0,                                       
	0,
	null,
	0,                                
	null,   
	lag(av.visit_occurrence_id) 
	 over(partition by p.person_id
			  order by av.visit_start_date)
from @cdm_schema.all_visits av
join @cdm_schema.person p
  on av.patient = p.person_source_value
join @synthea_schema.encounters e
  on av.encounter_id = e.id
 and av.patient = e.patient
join @cdm_schema.provider pr 
  on e.provider = pr.provider_source_value
where av.visit_occurrence_id in (
		select distinct visit_occurrence_id_new
		from @cdm_schema.final_visit_ids);